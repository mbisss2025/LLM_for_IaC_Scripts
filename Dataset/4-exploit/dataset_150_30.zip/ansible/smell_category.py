import pandas as pd
import re

# Définition des catégories et des mots-clés associés
# L'ordre est important : les premières correspondances seront prioritaires.
# Les mots-clés doivent être en minuscules pour une comparaison insensible à la casse.
# Les noms des catégories correspondent EXACTEMENT à votre liste.
CLASSIFICATION_RULES = [
    ("Command Injection", [
        "command injection", "os command", "shell command", "remote command execution", "rce", 
        "process control", "arbitrary command", "runtime.exec", "system\\(", "subprocess.run", 
        "execution of user-controlled"
    ]),
    ("Path Traversal", [
        "path traversal", "directory traversal", "../", "file inclusion", "zip slip", 
        "path manipulation", "filename manipulation", "arbitrary file access", 
        "file system access with user input", "inclusion of functionality from an http GET parameter",
        "arbitrary file write via archive extraction", "tar slip" # Ajouté
    ]),
    ("Code Injection", [
        "code injection", "eval could be dangerous", "expression language injection", 
        "template injection", "deserialization of untrusted data", "unsafe deserialization", 
        "arbitrary code execution", "server-side template injection", "ssti", 
        "pickle load", "yaml.load", "remote code execution", "object injection",
        "dynamic code execution", "unsafe reflection"
    ]),
    ("Insecure Input Handling", [ 
        "input validation", "unvalidated input", "unsanitized input", "tainted input", 
        "format string vulnerability", "open redirect", "http header injection", 
        "redos", "regular expression denial of service", "type juggling", "mass assignment",
        "improper neutralization of special elements", "cross-frame scripting",
        "sql injection", "sqli", "database query with user input",
        "cross-site scripting", "xss", "reflected xss", "stored xss", "dom xss", "content spoofing", "html injection",
        "jinja auto-escape is set to false", "auto-escape off", "template autoescape disabled", # Ajouté
        "xxe", "xml external entity", "xml parsers should not be vulnerable to xxe attacks", "insecure xml parser", "unsafe xml parsing", # Ajouté
        "ssrf", "server-side request forgery", "request forgery", "url redirection to untrusted site"
    ]),
    ("Sensitive Information Exposure", [
        "sensitive data leak", "information exposure", "credentials exposure", 
        "hardcoded secret", "hard-coded key", "hard-coded password", "hardcoded api key", "hardcoded credentials",
        "token exposure", "private key disclosure", "debug information enabled", "stack trace exposure", 
        "sensitive information in logs", "api key leak", "session information leak", 
        "cleartext storage of sensitive information", "cleartext transmission of sensitive information", 
        "insufficiently random values", "predictable random", "weak prng", "information disclosure", 
        "exposure of private information", "password in comment", "leaking of c-style format strings",
        "android logcat data leak", "insecure storage of sensitive data"
    ]),
    ("Insecure Configuration Management", [
        "security misconfiguration", "insecure configuration", "default credential", "default password",
        "weak configuration", "exposed admin", "weak cryptography", "weak encryption", "use of weak ssl/tls ciphers",
        "broken cryptographic algorithm", "insecure tls", "insecure ssl", "weak cipher", "ecb mode",
        "missing security header", "csrf protection", "cross-site request forgery", "clickjacking", "iframe injection",
        "directory listing enabled", "weak cookie", "insecure transport settings", 
        "improper certificate validation", "tls certificate not verified", "cors misconfiguration", "permissive cors policy",
        "missing httpOnly", "missing secure flag for cookie", "android component exposed",
        "permissions", "authorization", "access control", "improper authorization", "missing authorization", "broken access control",
        "use of http without tls", "unsafe domain binding for postmessage",
        "use of password hash with insufficient computational effort", "password hash weak", "insufficient iteration", # Ajouté
        "selection of less-secure algorithm during negotiation", "ssl instead of tls", "weak tls version" # Ajouté
    ]),
    ("Insecure Dependency Management", [ 
        "vulnerable dependency", "library with known vulnerability", "insecure library usage", 
        "component with known vulnerabilities", "use of component with known vulnerabilities",
        "dependency confusion"
    ]),
    ("Outdated Dependencies", [ 
        "outdated dependency", "vulnerable version of library", "update component to version", 
        "known security issues in version", "end-of-life library", "unmaintained dependency",
        "library out-of-date"
    ]),
    ("Outdated Software Version", [ 
        "outdated software", "old version of component", "unsupported software version", 
        "end-of-life software", "outdated api usage", "deprecated function" 
    ]),
    ("Inadequate Naming Convention", [ 
        "naming convention", "unclear name", "confusing variable name", 
        "poorly named function", "ambiguous name", "magic number", "unnamed constant"
    ])
]


def classify_vulnerability(description, rules):
    """
    Classe une description de vulnérabilité dans une catégorie prédéfinie.
    Args:
        description (str): La description de la vulnérabilité.
        rules (list): Une liste de tuples (nom_categorie, [mots_cles]).
    Returns:
        str: Le nom de la catégorie correspondante ou "Uncategorized".
    """
    if pd.isna(description) or not isinstance(description, str) or not description.strip():
        return "Uncategorized (Empty Description)"

    description_lower = description.lower()
    for category, keywords in rules:
        for keyword in keywords:
            # Utiliser \b pour s'assurer que le mot-clé est un mot entier (ou au début/fin)
            # afin d'éviter les correspondances partielles (ex: "os" dans "cosmos")
            # Sauf si le mot-clé est court et une correspondance partielle est souhaitée (ex: "xss")
            if len(keyword) > 3: 
                pattern = r'\b' + re.escape(keyword.lower()) + r'\b'
            else: 
                pattern = re.escape(keyword.lower())
            
            if re.search(pattern, description_lower):
                return category # Retourne le nom exact de la catégorie de votre liste
    return "Uncategorized"

def categorize_vulnerabilities_in_excel(input_excel_path, output_excel_path, 
                                        vulnerability_column_name, new_category_column_name):
    """
    Lit un fichier Excel, classe les vulnérabilités et enregistre le résultat.
    """
    try:
        df = pd.read_excel(input_excel_path)
        print(f"Fichier d'entrée '{input_excel_path}' lu avec succès. Nombre de lignes: {len(df)}")
    except FileNotFoundError:
        print(f"ERREUR : Le fichier d'entrée '{input_excel_path}' n'a pas été trouvé.")
        return
    except Exception as e:
        print(f"ERREUR : Impossible de lire le fichier Excel '{input_excel_path}': {e}")
        return

    if vulnerability_column_name not in df.columns:
        print(f"ERREUR : La colonne source '{vulnerability_column_name}' n'est pas présente dans le fichier Excel.")
        print(f"Colonnes disponibles : {df.columns.tolist()}")
        return

    print(f"Classification des entrées de la colonne '{vulnerability_column_name}'...")
    df[new_category_column_name] = df[vulnerability_column_name].apply(lambda desc: classify_vulnerability(desc, CLASSIFICATION_RULES))
    print("Classification terminée.")

    print("\nAperçu des catégories attribuées :")
    print(df[new_category_column_name].value_counts(dropna=False))

    try:
        df.to_excel(output_excel_path, index=False)
        print(f"\nFichier modifié avec la nouvelle colonne de catégorie sauvegardé avec succès sous '{output_excel_path}'.")
    except Exception as e:
        print(f"ERREUR : Impossible d'écrire le fichier Excel de sortie '{output_excel_path}': {e}")

# --- Configuration ---
# REMPLACEZ CES VALEURS SI NÉCESSAIRE

# Fichier Excel d'entrée (doit contenir la colonne avec les descriptions de vulnérabilités)
INPUT_EXCEL_FILE = "terraform_snyk_code_snippets_categories_uniques.xlsx" # Par exemple, ou votre fichier snyk_code_analysis_final.xlsx

# Nom du fichier Excel de sortie
OUTPUT_EXCEL_CATEGORIZED_FILE = "snyk_analysis_smell_categories_terraform.xlsx" # Nom de sortie mis à jour

# Nom de la colonne dans votre fichier d'entrée qui contient la description de la vulnérabilité
VULNERABILITY_SOURCE_COLUMN = "vulnerability" # Assurez-vous que ce nom de colonne existe

# Nom de la nouvelle colonne qui contiendra la catégorie de "smell security"
NEW_CATEGORY_COLUMN = "smell_category"
# --------------------

if __name__ == "__main__":
    categorize_vulnerabilities_in_excel(
        INPUT_EXCEL_FILE,
        OUTPUT_EXCEL_CATEGORIZED_FILE,
        VULNERABILITY_SOURCE_COLUMN,
        NEW_CATEGORY_COLUMN
    )