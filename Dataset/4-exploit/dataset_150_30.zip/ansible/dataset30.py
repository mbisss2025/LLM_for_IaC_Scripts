import pandas as pd
import numpy as np # Facultatif, pour pd.NA si besoin

def sample_entries_per_category(input_excel_path, 
                                output_selected_path, 
                                output_remaining_path,
                                category_column_name="smell_security_category", 
                                num_to_select_per_category=3,
                                random_seed=None):
    """
    Lit un fichier Excel avec des catégories, sélectionne un nombre spécifié d'entrées
    aléatoires pour chaque catégorie, et enregistre les entrées sélectionnées et 
    les restantes dans des fichiers Excel séparés.

    Args:
        input_excel_path (str): Chemin vers le fichier Excel d'entrée catégorisé.
        output_selected_path (str): Chemin pour sauvegarder les entrées sélectionnées.
        output_remaining_path (str): Chemin pour sauvegarder les entrées restantes.
        category_column_name (str): Nom de la colonne contenant les catégories.
        num_to_select_per_category (int): Nombre d'entrées à sélectionner par catégorie.
        random_seed (int, optional): Graine pour le générateur de nombres aléatoires.
    """
    try:
        df = pd.read_excel(input_excel_path)
        print(f"Fichier d'entrée '{input_excel_path}' lu avec succès. Nombre de lignes initial: {len(df)}")
    except FileNotFoundError:
        print(f"ERREUR : Le fichier d'entrée '{input_excel_path}' n'a pas été trouvé.")
        return
    except Exception as e:
        print(f"ERREUR : Impossible de lire le fichier Excel '{input_excel_path}': {e}")
        return

    if category_column_name not in df.columns:
        print(f"ERREUR : La colonne de catégorie '{category_column_name}' n'est pas présente dans le fichier Excel.")
        print(f"Colonnes disponibles : {df.columns.tolist()}")
        return

    print(f"Sélection de jusqu'à {num_to_select_per_category} entrées par catégorie de la colonne '{category_column_name}'...")

    # S'assurer que la colonne de catégorie n'a pas de NaN qui pourraient gêner le groupby
    # Remplacer les NaN par une chaîne placeholder si nécessaire, ou les supprimer.
    # Pour cet exemple, on va supposer que les catégories sont des chaînes valides.
    # Si "Uncategorized" est une chaîne valide, c'est bon.
    # Si la colonne peut contenir de vrais NaN que vous voulez ignorer ou traiter à part :
    # df_valid_categories = df.dropna(subset=[category_column_name])
    # ou df[category_column_name] = df[category_column_name].fillna("CATEGORY_UNKNOWN")

    # pandas groupby().sample() est parfait pour cela.
    # Si une catégorie a moins de 'num_to_select_per_category' entrées, il les prendra toutes.
    
    # Assurer que l'échantillonnage est fait de manière reproductible si random_seed est fourni
    # et gérer les groupes plus petits que num_to_select_per_category
    
    selected_dfs = []
    all_indices = set(df.index)
    processed_indices = set()

    for category_value, group_df in df.groupby(category_column_name):
        n_in_group = len(group_df)
        n_to_sample = min(num_to_select_per_category, n_in_group)
        
        if n_to_sample > 0:
            sampled_group = group_df.sample(n=n_to_sample, random_state=random_seed)
            selected_dfs.append(sampled_group)
            processed_indices.update(sampled_group.index) # Garder une trace des index sélectionnés
            print(f"  Catégorie '{category_value}': {len(sampled_group)}/{n_in_group} entrées sélectionnées.")
        else:
            print(f"  Catégorie '{category_value}': Aucune entrée à échantillonner (groupe vide ou n_to_sample=0).")


    if not selected_dfs:
        print("Aucune entrée n'a été sélectionnée (peut-être que toutes les catégories étaient vides ou non valides).")
        # Créer des fichiers vides ou des fichiers avec seulement les en-têtes
        pd.DataFrame(columns=df.columns).to_excel(output_selected_path, index=False)
        df.to_excel(output_remaining_path, index=False) # Toutes les lignes sont restantes
        print(f"Fichier des entrées sélectionnées (vide) '{output_selected_path}' créé.")
        print(f"Fichier des entrées restantes (toutes les lignes) '{output_remaining_path}' créé.")
        return
        
    df_selected = pd.concat(selected_dfs)

    # Identifier les lignes restantes
    remaining_indices = list(all_indices - processed_indices)
    df_remaining = df.loc[remaining_indices]

    print(f"\nTotal d'entrées sélectionnées : {len(df_selected)}")
    print(f"Total d'entrées restantes : {len(df_remaining)}")

    try:
        df_selected.to_excel(output_selected_path, index=False)
        print(f"Fichier avec les entrées sélectionnées sauvegardé avec succès sous '{output_selected_path}'.")
    except Exception as e:
        print(f"ERREUR : Impossible d'écrire le fichier des entrées sélectionnées '{output_selected_path}': {e}")

    try:
        df_remaining.to_excel(output_remaining_path, index=False)
        print(f"Fichier avec les entrées restantes sauvegardé avec succès sous '{output_remaining_path}'.")
    except Exception as e:
        print(f"ERREUR : Impossible d'écrire le fichier des entrées restantes '{output_remaining_path}': {e}")


# --- Configuration ---
# REMPLACEZ CES VALEURS SI NÉCESSAIRE

# Fichier Excel d'entrée (celui qui contient la colonne des catégories)
# Par exemple: "snyk_analysis_smell_categories_v3.xlsx"
INPUT_CATEGORIZED_EXCEL_FILE = "vagrant_snyk_analysis_smells-final.xlsx" 

# Nom du fichier Excel de sortie pour les entrées sélectionnées
OUTPUT_SELECTED_ENTRIES_FILE = "vagrant_echantillon_par_categorie.xlsx"

# Nom du fichier Excel de sortie pour les entrées restantes
OUTPUT_REMAINING_ENTRIES_FILE = "vagrant_entrees_restantes_apres_echantillonnage.xlsx"

# Nom de la colonne dans votre fichier d'entrée qui contient les catégories
# (par exemple, 'smell_security_category')
CATEGORY_COLUMN_FOR_SAMPLING = "smell_category"

# Nombre d'entrées à sélectionner pour chaque catégorie
NUM_ENTRIES_PER_CATEGORY = 5

# Graine pour la sélection aléatoire (pour la reproductibilité des résultats).
# Mettez None si vous voulez une sélection différente à chaque fois.
RANDOM_SEED_VALUE = 42 
# --------------------

if __name__ == "__main__":
    sample_entries_per_category(
        INPUT_CATEGORIZED_EXCEL_FILE,
        OUTPUT_SELECTED_ENTRIES_FILE,
        OUTPUT_REMAINING_ENTRIES_FILE,
        category_column_name=CATEGORY_COLUMN_FOR_SAMPLING,
        num_to_select_per_category=NUM_ENTRIES_PER_CATEGORY,
        random_seed=RANDOM_SEED_VALUE
    )